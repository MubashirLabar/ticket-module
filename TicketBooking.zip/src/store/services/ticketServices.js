import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

const ticketServices = createApi({
  reducerPath: "ticket",
  tagType: "ticket-booking",
  baseQuery: fetchBaseQuery({
    baseUrl: "https://kzyr3n2xc0.execute-api.eu-central-1.amazonaws.com",
    prepareHeaders: (headers, { getState }) => {
      const reducers = getState();
      const token = reducers?.authReducer?.token;
      headers.set("authorization", token ? `Bearer ${token}` : "");
      return headers;
    },
  }),
  endpoints: (builder) => {
    return {
      getTicketsInfo: builder.query({
        query: (id) => {
          return {
            url: `/dev/users/validateBookingViaLink/${id}`,
            method: "GET",
          };
        },
        providesTags: ["ticket-booking"],
      }),
    };
  },
});

export const { useGetTicketsInfoQuery } = ticketServices;

export default ticketServices;
