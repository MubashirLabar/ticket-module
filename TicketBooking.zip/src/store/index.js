import { configureStore } from "@reduxjs/toolkit";
import ticketServices from "./services/ticketServices";

const Store = configureStore({
  reducer: {
    [ticketServices.reducerPath]: ticketServices.reducer,
  },
});

export default Store;
