import React, { useState, useEffect } from "react";
import { toast } from "react-toastify";
import { useParams } from "react-router-dom";
import axios from "axios";
import { ChevronsIconLeft, ChevronsIconRight } from "assets/icon";

import StepOne from "./StepOne";
import StepTwo from "./StepTwo";
import StepThree from "./StepThree";
import { useGetTicketsInfoQuery } from "store/services/ticketServices";
import { Loader } from "components";

function Home() {
  const { id } = useParams();
  const [sleetedStep, setSelectedStep] = useState(1);
  const { data = [], isFetching } = useGetTicketsInfoQuery(id);
  const [totalPrice, setTotalPrice] = useState(0);
  const [loading, setLoading] = useState(false);

  const [ticketFields, setTicketFields] = useState({
    scheduleClassId: "",
    type: "add",
    isPackage: false,
    isEvent: true,
    username: "",
    fullName: "",
    isPaid: "false",
    selectedEventPricing: [],
  });

  const [regularTicket, setRegularTicket] = useState({
    ticketType: "Regular",
    quantity: 0,
    amount: 0,
  });

  const [premiumTicket, setPremiumTicket] = useState({
    ticketType: "Premium",
    quantity: 0,
    amount: 0,
  });

  const [vipTicket, setVipTicket] = useState({
    ticketType: "VIP",
    quantity: 0,
    amount: 0,
  });

  const nextStep = () => {
    if (sleetedStep === 1) {
      handleStepOne();
    } else if (sleetedStep === 2) {
      handleStepTwo();
    }
  };

  const prevStep = () => {
    setSelectedStep(sleetedStep - 1);
  };

  const handleStepOne = () => {
    if (!ticketFields.selectedEventPricing.length) {
      toast("Select at least once ticket", {
        type: "error",
      });
    } else {
      setTicketFields({
        ...ticketFields,
        scheduleClassId: data?.data?.scheduleClassId,
      });
      setSelectedStep(sleetedStep + 1);
    }
  };

  const handleStepTwo = () => {
    if (!ticketFields.fullName) {
      toast("Full name is required", {
        type: "error",
      });
    }
    // else if (!ticketFields.username) {
    //   toast("Email is required", {
    //     type: "error",
    //   });
    // } else if (!isValidEmail(ticketFields.username)) {
    //   toast("Email is invalid", {
    //     type: "error",
    //   });
    // }
    else {
      setSelectedStep(sleetedStep + 1);
    }
  };

  const placeOrderButton = async () => {
    setLoading(true);
    try {
      const config = {
        method: "post",
        url: "https://kzyr3n2xc0.execute-api.eu-central-1.amazonaws.com/dev/users/addParticipant",
        headers: {
          "Content-Type": "application/json",
        },
        data: {
          scheduleClassId: ticketFields.scheduleClassId,
          type: "add",
          isPackage: false,
          isEvent: true,
          username: ticketFields.username,
          fullName: ticketFields.fullName,
          isPaid: "false",
          selectedEventPricing: ticketFields.selectedEventPricing,
        },
      };
      axios(config)
        .then(function (response) {
          console.log("response...", response.data);
          toast(response?.data?.message, {
            type: "success",
          });
          setLoading(false);
          setSelectedStep(1);
        })
        .catch(function (error) {
          console.log(error);
          toast(error.message, {
            type: "error",
          });
          setLoading(false);
        });
    } catch (error) {
      console.log("error....", error);
      toast(error.message, {
        type: "error",
      });
      setLoading(false);
    }
  };

  if (isFetching) {
    return (
      <div className="ticket-view-loading">
        <Loader size={40} />
      </div>
    );
  }

  console.log("ticketFields...", ticketFields);

  return (
    <div className="ticket-booking">
      <div className="wrapper">
        <div className="page-hdr">
          {sleetedStep > 1 && (
            <button className="back-btn" onClick={prevStep}>
              <ChevronsIconLeft />
              <div className="lbl">Back</div>
            </button>
          )}
          <div className="title">
            {sleetedStep === 1
              ? "Tickets"
              : sleetedStep === 2
              ? "Information"
              : sleetedStep === 3
              ? "Payment"
              : ""}
            &nbsp;<span>{`${sleetedStep}/3`}</span>
          </div>
        </div>
        <div className="content">
          <>
            {sleetedStep === 1 && (
              <StepOne
                data={data}
                regularTicket={regularTicket}
                setRegularTicket={setRegularTicket}
                premiumTicket={premiumTicket}
                setPremiumTicket={setPremiumTicket}
                vipTicket={vipTicket}
                setVipTicket={setVipTicket}
                setTotalPrice={setTotalPrice}
                ticketFields={ticketFields}
                setTicketFields={setTicketFields}
              />
            )}
            {sleetedStep === 2 && (
              <StepTwo
                ticketFields={ticketFields}
                setTicketFields={setTicketFields}
              />
            )}
            {sleetedStep === 3 && <StepThree />}
          </>
          {/* Sub Total */}
          <div className="sub-total-blk">
            <div className="meta">
              <div className="title">Total (incl. tax & €0.00 booking fee)</div>
              <div className="price">€{totalPrice.toFixed(2)}</div>
            </div>
            <div className="rit">
              {sleetedStep === 3 ? (
                <button
                  className="button-primary next-btn"
                  onClick={placeOrderButton}
                >
                  Place Order
                </button>
              ) : (
                <button className="button-primary next-btn" onClick={nextStep}>
                  Next <ChevronsIconRight />
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
      {loading && (
        <div className="overlay">
          <Loader />
        </div>
      )}
    </div>
  );
}

export default Home;
