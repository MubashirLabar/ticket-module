import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { CheckIcon, MinusIcon, PercentageIcon, PlusIcon } from "assets/icon";
import moment from "moment";

function StepOne({
  data,
  regularTicket,
  setRegularTicket,
  premiumTicket,
  setPremiumTicket,
  vipTicket,
  setVipTicket,
  setTotalPrice,
  ticketFields,
  setTicketFields,
}) {
  const [openPromoCode, setOpenPromoCode] = useState(false);
  const [promoCode, setPromoCode] = useState("");
  const [agreeTerms, setAgreeTerms] = useState(false);

  useEffect(() => {
    let total = regularTicket.amount + premiumTicket.amount + vipTicket.amount;
    setTotalPrice(total);
  }, [regularTicket]);

  useEffect(() => {
    let total = regularTicket.amount + premiumTicket.amount + vipTicket.amount;
    setTotalPrice(total);
  }, [premiumTicket]);

  useEffect(() => {
    let total = regularTicket.amount + premiumTicket.amount + vipTicket.amount;
    setTotalPrice(total);
  }, [vipTicket]);

  const minusTicketButton = (item) => {
    let updatedTickets = ticketFields.selectedEventPricing;
    if (item.ticketType === "Regular") {
      let quantity = regularTicket.quantity - 1;
      let object = {
        ticketType: "Regular",
        quantity: quantity,
        amount: parseInt(regularTicket.amount) - parseInt(item.amount),
      };
      setRegularTicket(object);

      if (quantity === 0) {
        var newArray = updatedTickets.filter(
          (x) => x.ticketType !== item.ticketType
        );
        setTicketFields({
          ...ticketFields,
          selectedEventPricing: newArray,
        });
      } else {
        var foundIndex = updatedTickets.findIndex(
          (x) => x.ticketType === item.ticketType
        );
        if (foundIndex >= 0) {
          updatedTickets[foundIndex] = object;
          setTicketFields({
            ...ticketFields,
            selectedEventPricing: updatedTickets,
          });
        }
      }
    }

    if (item.ticketType === "Premium") {
      let quantity = premiumTicket.quantity - 1;
      let object = {
        ticketType: "Premium",
        quantity: quantity,
        amount: parseInt(premiumTicket.amount) - parseInt(item.amount),
      };
      setPremiumTicket(object);
      if (quantity === 0) {
        var newArray = updatedTickets.filter(
          (x) => x.ticketType !== item.ticketType
        );
        setTicketFields({
          ...ticketFields,
          selectedEventPricing: newArray,
        });
      } else {
        var foundIndex = updatedTickets.findIndex(
          (x) => x.ticketType === item.ticketType
        );
        if (foundIndex >= 0) {
          updatedTickets[foundIndex] = object;
          setTicketFields({
            ...ticketFields,
            selectedEventPricing: updatedTickets,
          });
        }
      }
    }

    if (item.ticketType === "VIP") {
      let quantity = vipTicket.quantity - 1;
      let object = {
        ticketType: "VIP",
        quantity: quantity,
        amount: parseInt(vipTicket.amount) - parseInt(item.amount),
      };
      setVipTicket(object);
      if (quantity === 0) {
        var newArray = updatedTickets.filter(
          (x) => x.ticketType !== item.ticketType
        );
        setTicketFields({
          ...ticketFields,
          selectedEventPricing: newArray,
        });
      } else {
        var foundIndex = updatedTickets.findIndex(
          (x) => x.ticketType === item.ticketType
        );
        if (foundIndex >= 0) {
          updatedTickets[foundIndex] = object;
          setTicketFields({
            ...ticketFields,
            selectedEventPricing: updatedTickets,
          });
        }
      }
    }
  };

  const addTicketButton = (item) => {
    let updatedTickets = ticketFields.selectedEventPricing;
    if (item.ticketType === "Regular") {
      let quantity = regularTicket.quantity + 1;
      let object = {
        ticketType: "Regular",
        quantity: quantity,
        amount: quantity * parseInt(item.amount),
      };

      setRegularTicket(object);

      var foundIndex = updatedTickets.findIndex(
        (x) => x.ticketType === item.ticketType
      );
      if (foundIndex >= 0 && updatedTickets.length) {
        updatedTickets[foundIndex] = object;
        setTicketFields({
          ...ticketFields,
          selectedEventPricing: updatedTickets,
        });
      } else {
        setTicketFields({
          ...ticketFields,
          selectedEventPricing: [...ticketFields.selectedEventPricing, object],
        });
      }
    }

    if (item.ticketType === "Premium") {
      let quantity = premiumTicket.quantity + 1;
      let object = {
        ticketType: "Premium",
        quantity: quantity,
        amount: quantity * parseInt(item.amount),
      };
      setPremiumTicket(object);
      var foundIndex = updatedTickets.findIndex(
        (x) => x.ticketType === item.ticketType
      );
      if (foundIndex >= 0 && updatedTickets.length) {
        updatedTickets[foundIndex] = object;
        setTicketFields({
          ...ticketFields,
          selectedEventPricing: updatedTickets,
        });
      } else {
        setTicketFields({
          ...ticketFields,
          selectedEventPricing: [...ticketFields.selectedEventPricing, object],
        });
      }
    }

    if (item.ticketType === "VIP") {
      let quantity = vipTicket.quantity + 1;
      let object = {
        ticketType: "VIP",
        quantity: vipTicket.quantity + 1,
        amount: quantity * parseInt(item.amount),
      };
      setVipTicket(object);

      var foundIndex = updatedTickets.findIndex(
        (x) => x.ticketType === item.ticketType
      );
      if (foundIndex >= 0 && updatedTickets.length) {
        updatedTickets[foundIndex] = object;
        setTicketFields({
          ...ticketFields,
          selectedEventPricing: updatedTickets,
        });
      } else {
        setTicketFields({
          ...ticketFields,
          selectedEventPricing: [...ticketFields.selectedEventPricing, object],
        });
      }
    }
  };

  var date1 = new Date(data?.data?.classDate);
  var date2 = new Date(data?.data?.classEndDate);

  let classDate = moment(date1).format("MM/DD/YY hh:mm A");
  let classEndDate = moment(date2).format("MM/DD/YY hh:mm A");

  return (
    <div className="ticket-booking_step-one">
      <div className="section">
        <div className="block info">
          <div
            className="image"
            style={{
              backgroundImage: `url(${data?.data?.classPhoto})`,
            }}
          />
          <div className="meta">
            <div className="title">{data?.data?.className}</div>
            <div className="stamp">{`${classDate} - ${classEndDate}`}</div>
            <div className="location">{data?.data?.location?.addressName}</div>
          </div>
        </div>
        <div className="block ticket-types">
          {data?.data?.eventPricingList.length &&
            data.data.eventPricingList.map((item, index) => (
              <div className="item" key={index}>
                <div className="lit">
                  <div className="meta">
                    <div className="title">{item.ticketType}</div>
                    {/* <div className="text">€10.00 + €1.00 fee.</div> */}
                  </div>
                </div>
                <div className="rit">
                  {item.ticketType === "Regular" && (
                    <>
                      <div className="actions">
                        <button
                          className="action"
                          onClick={() => minusTicketButton(item)}
                          disabled={regularTicket?.quantity <= 0}
                        >
                          <MinusIcon />
                        </button>
                        <div className="price">{regularTicket?.quantity}</div>
                        <button
                          className="action"
                          onClick={() => addTicketButton(item)}
                        >
                          <PlusIcon />
                        </button>
                      </div>
                      <div
                        className={`sub-total ${
                          regularTicket?.amount ? "active" : ""
                        }`}
                      >
                        €{regularTicket?.amount.toFixed(2)}
                      </div>
                    </>
                  )}
                  {item.ticketType === "Premium" && (
                    <>
                      <div className="actions">
                        <button
                          className="action"
                          onClick={() => minusTicketButton(item)}
                          disabled={premiumTicket?.quantity <= 0}
                        >
                          <MinusIcon />
                        </button>
                        <div className="price">{premiumTicket?.quantity}</div>
                        <button
                          className="action"
                          onClick={() => addTicketButton(item)}
                        >
                          <PlusIcon />
                        </button>
                      </div>
                      <div
                        className={`sub-total ${
                          premiumTicket?.amount ? "active" : ""
                        }`}
                      >
                        €{premiumTicket?.amount.toFixed(2)}
                      </div>
                    </>
                  )}
                  {item.ticketType === "VIP" && (
                    <>
                      <div className="actions">
                        <button
                          className="action"
                          onClick={() => minusTicketButton(item)}
                          disabled={vipTicket?.quantity <= 0}
                        >
                          <MinusIcon />
                        </button>
                        <div className="price">{vipTicket?.quantity}</div>
                        <button
                          className="action"
                          onClick={() => addTicketButton(item)}
                        >
                          <PlusIcon />
                        </button>
                      </div>
                      <div
                        className={`sub-total ${
                          vipTicket?.amount ? "active" : ""
                        }`}
                      >
                        €{vipTicket?.amount.toFixed(2)}
                      </div>
                    </>
                  )}
                </div>
              </div>
            ))}
        </div>
      </div>

      {/* Promo Code */}
      <div className="section promotional">
        {openPromoCode ? (
          <div className="promo-field">
            <div className="icon">
              <PercentageIcon />
            </div>
            <input
              types="text"
              placeholder="Promotional code"
              className="input"
              value={promoCode}
              onChange={(e) => setPromoCode(e.target.value)}
            />
            <button className="button-primary add-btn" disabled={!promoCode}>
              Add
            </button>
          </div>
        ) : (
          <button className="promo-btn" onClick={() => setOpenPromoCode(true)}>
            <PercentageIcon />
            <div className="lbl">Enter a promotional code</div>
          </button>
        )}
      </div>

      {/* Terms and Condition */}
      <label
        className="section terms"
        onClick={() => setAgreeTerms(!agreeTerms)}
      >
        <div className={`checkbox ${agreeTerms ? "active" : ""}`}>
          <CheckIcon />
        </div>
        <div className="lbl">
          I agree to the{" "}
          <Link to="/" className="link">
            terms of service
          </Link>{" "}
          of Eventix
        </div>
      </label>
    </div>
  );
}

export default StepOne;
