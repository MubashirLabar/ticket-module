import React from "react";

function StepThree() {
  return (
    <div className="ticket-booking_step-three">
      <div className="section">
        <div className="block">
          <div className="item">
            <div className="lit">
              <div className="meta">
                <div className="title">On Delivery Time</div>
                <div className="text">Free</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default StepThree;
