import React, { Suspense, lazy } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";

// Components
import { Splash } from "components";

// Pages
const TicketBooking = lazy(() => import("views/TicketBooking"));

const Routing = () => {
  return (
    <BrowserRouter>
      {/* <Suspense fallback={<Splash />}> */}
      <Routes>
        <Route path="/:id" element={<TicketBooking />} />
      </Routes>
      {/* </Suspense> */}
    </BrowserRouter>
  );
};

export default Routing;
