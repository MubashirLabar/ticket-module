import React from "react";

function Splash() {
  return (
    <div className="splash-screen">
      <div className="logo flex aic">
        <div className="text">Ticket Booking</div>
      </div>
    </div>
  );
}

export default Splash;
